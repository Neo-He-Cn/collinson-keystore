# Android Keystore Credentials

These credentials are used in conjunction with your Android keystore file to sign your app for distribution.

## Credential Values

- Android keystore password: 15fd9f28-0d45-11e8-97eb-0a580a782815
- Android key alias: QG1heGdlbmRhbmllbC9jb2xsaW5zb25meA==
- Android key password: 15fd9f34-0d45-11e8-97eb-0a580a782815
      