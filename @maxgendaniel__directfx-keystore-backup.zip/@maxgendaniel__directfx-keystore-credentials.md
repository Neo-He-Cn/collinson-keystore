# Android Keystore Credentials

These credentials are used in conjunction with your Android keystore file to sign your app for distribution.

## Credential Values

- Android keystore password: 3ef6b382-a8a9-11e7-a800-0a580a780266
- Android key alias: QG1heGdlbmRhbmllbC9kaXJlY3RmeA==
- Android key password: 3ef6b3b7-a8a9-11e7-a800-0a580a780266
      